#ifndef __MERIDIAN_MOVEMENT_MOTIONPLAY_H__
#define __MERIDIAN_MOVEMENT_MOTIONPLAY_H__

#include "main.h"
#include "config.h"

//================================================================================================================
//  モーション再生関連の処理  ---------------------------------------------------------------------------------------
//================================================================================================================

/// @brief スタブ関数.
/// @return 常にfalseを返す.
bool mrd_mv_motionplay_x()
{
    return false;
}

#endif // __MERIDIAN_MOVEMENT_MOTIONPLAY_H__
